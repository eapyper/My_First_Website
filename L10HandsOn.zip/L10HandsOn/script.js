$(document).ready(function(){
    $(".mediaPic").hover(function(){
        $(this).css("width", "200px");
        $(this).css("height", "auto");
    }, function(){
        $(this).css("width", "160px");
        $(this).css("height", "auto");
    });
    $("#facebook").click(function(){
        window.open('https://www.facebook.com/profile.php?id=100004244295577&ref=bookmarks', '_blank');
    });
    $("#gitHub").click(function(){
        window.open('https://github.com/eapyper', '_blank');
    });
    $("#linkedIn").click(function(){
        window.open('https://www.linkedin.com/in/ethan-pyper-0568031aa/', '_blank');
    });
});

let gitHubRequest = new XMLHttpRequest();
gitHubRequest.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
    let gitObject = JSON.parse(this.responseText);
    var repoContainers = document.getElementsByClassName("repoContainer");
     for (const i in repoContainers) {
         if (gitObject[i] != undefined && gitObject[i].name != null ) {
             repoContainers[i].innerHTML = gitObject[i].name;
         } else{
            repoContainers[i].innerHTML = "Coming Soon!"
         }
     }
   // document.getElementById("repoContainer").innerHTML = gitObject[0].name;
    console.log(gitObject)
  }
};
gitHubRequest.open("GET", "https://api.github.com/users/eapyper/repos", true);
gitHubRequest.send();